import { Body, Controller, Delete, Get, HttpException, Param, Post, Put, Query } from "@nestjs/common";
import { NoteDto } from "./dto/note.dto";
import { NoteService } from "./note.service";
import { NoteDocument } from "../schemas/note.schema";


@Controller()
export class NoteController {
  constructor(
    private readonly noteService: NoteService
  ) {
  }

  @Post("create/:id")
  async create(@Body() createNote: NoteDto, @Param("id") id: string): Promise<NoteDocument> {
    return await this.noteService.create(createNote, id);
  }

  @Get(":id")
  async getSort(@Query("sort") sort: string, @Param("id") id: string): Promise<NoteDocument[]> {
    return await this.noteService.getSort(sort, id);
  }

  @Delete("delete/:id")
  async delete(@Param("id") id: number): Promise<HttpException> {
    return await this.noteService.delete(id);
  }

  @Put("update/:id")
  async update(@Body() updateNote: NoteDto, @Param("id") id: number): Promise<NoteDocument> {
    return this.noteService.update(updateNote, id);
  }
}