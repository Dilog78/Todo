import { Body, Controller, Get, Param, Post } from "@nestjs/common";
import { UserService } from "./user.service";
import { UserDto } from "./dto/user.dto";
import { UserInterface } from "./types/user.interface";


@Controller()
export class UserController {
  constructor(
    private readonly userService: UserService
  ) {}

  @Post('registration')
  async createUser(@Body() user: UserDto): Promise<UserInterface> {
    return await this.userService.createUser(user);
  }

  @Post('login')
  async login(@Body() user: UserDto): Promise<UserInterface> {
    return await this.userService.login(user);
  }

  @Get('user/:id')
  async getUser(@Param('id') id: string): Promise<UserInterface> {
    return await this.userService.getUser(id);
  }
}
