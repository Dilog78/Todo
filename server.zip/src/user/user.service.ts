import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { User, UserDocument } from "../schemas/user.schema";
import { UserDto } from "./dto/user.dto";
import { UserInterface } from "./types/user.interface";
import * as bcrypt from "bcrypt";

@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>
  ) {
  }

  async createUser(userDto: UserDto): Promise<UserInterface> {

    const check = await this.userModel.findOne({email: userDto.email});

    if(check) {
      throw new HttpException('email already exists', HttpStatus.UNPROCESSABLE_ENTITY );
    }

    userDto.password = await bcrypt.hash(userDto.password, 10);

    return await this.userModel.create(userDto).then(user => {
      user = JSON.parse(JSON.stringify(user));
      delete user.password;
      return user;
    })
      .catch(err => {
        throw new Error(err.message);
      });
  }

  async login(userDto: UserDto): Promise<UserInterface> {

    const user = await this.userModel.findOne({ email: userDto.email }).populate("note");
    if (!user) {
      throw new HttpException("Credentials are not valid", HttpStatus.UNPROCESSABLE_ENTITY);
    }

    const isValidPass = await bcrypt.compare(userDto.password, user.password);
    if (!isValidPass) {
      throw new HttpException("Credentials are not valid", HttpStatus.UNPROCESSABLE_ENTITY);
    }

    const userResponse = JSON.parse(JSON.stringify(user));
    delete userResponse.password;

    return userResponse.note;
  }

  async getUser(id: string): Promise<UserInterface> {
    return this.userModel.findById(id);
  }

}